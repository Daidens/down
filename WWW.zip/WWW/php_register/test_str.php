<?php


$str=' 123456';
$count = strlen($str);
for ($i=0;$i<$count;$i++){

	echo $str[$i],'<br>';
}